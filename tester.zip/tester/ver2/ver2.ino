#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

// Константы для расчетов
#define R_LOW 680
#define R_HIGH 470000

// Настройка LCD (согласно схеме)
#define LCD_PORT PORTD
#define LCD_DDR  DDRD
#define RS PD4
#define E  PD5

// --- Функции LCD ---
void lcd_send(uint8_t val, uint8_t is_data) {
    if(is_data) LCD_PORT |= (1<<RS); else LCD_PORT &= ~(1<<RS);
    // Старший ниббл
    LCD_PORT = (LCD_PORT & 0xF0) | (val >> 4);
    LCD_PORT |= (1<<E); _delay_us(1); LCD_PORT &= ~(1<<E);
    // Младший ниббл
    LCD_PORT = (LCD_PORT & 0xF0) | (val & 0x0F);
    LCD_PORT |= (1<<E); _delay_us(1); LCD_PORT &= ~(1<<E);
    _delay_ms(2);
}

void lcd_init() {
    LCD_DDR = 0x3F; // PD0-PD5 на выход
    _delay_ms(50);
    lcd_send(0x33, 0); lcd_send(0x32, 0); // Переход в 4-бит режим
    lcd_send(0x28, 0); lcd_send(0x0C, 0); lcd_send(0x01, 0);
}

void lcd_print(char *s) { while(*s) lcd_send(*s++, 1); }

// --- АЦП ---
void adc_init() {
    ADMUX = (1 << REFS0); // Опорное VCC (5V)
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1); // Делитель 64
}

uint16_t adc_read(uint8_t ch) {
    ADMUX = (ADMUX & 0xF0) | (ch & 0x0F);
    ADCSRA |= (1 << ADSC);
    while(ADCSRA & (1 << ADSC));
    return ADC;
}

// --- Логика измерения ---
void all_off() {
    DDRC &= ~((1<<PC0)|(1<<PC1)|(1<<PC2)|(1<<PC3)|(1<<PC4)|(1<<PC5));
    PORTC &= ~((1<<PC0)|(1<<PC1)|(1<<PC2)|(1<<PC3)|(1<<PC4)|(1<<PC5));
    DDRB &= ~((1<<PB0)|(1<<PB1)|(1<<PB2));
    PORTB &= ~((1<<PB0)|(1<<PB1)|(1<<PB2));
}

uint32_t get_resistor() {
    all_off();
   
    // Пин PC0 делаем выходом HIGH (+5V напрямую)
    DDRC |= (1 << PC0);
    PORTC |= (1 << PC0);
   
    // Пин PC1 подключаем к GND через резистор 680 Ом (на схеме это PC4)
    DDRC |= (1 << PC4);
    PORTC &= ~(1 << PC4);
   
    _delay_ms(20);
    uint16_t val = adc_read(1); // Читаем напряжение на PC1
   
    if(val < 10) return 0; // КЗ
    if(val > 1010) return 999999; // Обрыв
   
    // Формула: Rx = R_ref * (V_in - V_out) / V_out
    // Rx = 680 * (1023 - val) / val
    return (uint32_t)R_LOW * (1023 - val) / val;
}

int main() {
    lcd_init();
    adc_init();
    char buf[16];

    while(1) {
        uint32_t res = get_resistor();
        lcd_send(0x80, 0); // В начало первой строки
       
        if(res == 999999) {
            lcd_print("No component  ");
        } else {
            ltoa(res, buf, 10);
            lcd_print("R: ");
            lcd_print(buf);
            lcd_print(" Ohm      ");
        }
        _delay_ms(500);
    }
}
