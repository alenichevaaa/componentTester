int main(void) {
    DDRB = 0xFF;
    while(1) {
        PORTB ^= 0xFF;
        _delay_ms(500);
    }
}
